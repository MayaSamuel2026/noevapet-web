@echo off
setlocal
cd /d "%~dp0"
echo NoevaPet V25 deterministic qualification gate
echo.
where node >nul 2>nul || (echo ERROR: Node.js is required.& pause & exit /b 1)
node qa\v25-release-gate.mjs
if errorlevel 1 (
  echo.
  echo QA FAILED - do not deploy.
  pause
  exit /b 1
)
echo.
echo DETERMINISTIC QA PASSED.
echo For the full browser gate, GitHub Actions runs Playwright automatically on push.
pause
