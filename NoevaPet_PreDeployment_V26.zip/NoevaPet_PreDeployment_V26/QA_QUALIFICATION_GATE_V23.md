# NoevaPet Qualification Gate v2 — V23

V23 extends the V22 state gate with exact-product repurchase semantics.

## Canonical purchase intents for an existing product

1. **BUY / Heute nachkaufen** — exact product remains fixed, enters today's cart and triggers retailer-offer search.
2. **REMEMBER / Nur merken** — stays in the pet routine, does not enter today's cart and does not trigger retailer search.
3. **REPLACE / Alternative suchen** — current product stays as context but does not enter the cart; a concrete recommendation may replace it for this shopping trip.

## Additional hard invariants

- A repeat purchase marked BUY must preserve exact product identity and pack size through Pet Match, cart, buying route, checkout and history.
- Retailer optimisation may change retailer allocation and total route cost; it must never silently substitute an exact product.
- Exact-product retailer comparison requires sufficient product/variant information. If pack/variant cannot be inferred, the UI requests it before adding the item as an exact repurchase.
- A BUY exact product appears exactly once in the cart.
- REMEMBER exact products appear in pet context but contribute zero cart count.
- REPLACE products do not enter the cart; only the selected replacement does.
- Exact repurchase search requests use the existing catalogue/offer binding and request exact-match retailer offers.
- Completion preserves exact-product metadata in the immutable purchase record, then resets the routine item to REMEMBER for the next shopping trip.

## V22 invariants remain mandatory

All V22 pet, need, recommendation, cart-count, retailer-allocation, checkout, history, pet-switch and deletion invariants remain in force.

## Release sequence

BUILD → syntax/static integrity → V22 state suite → V23 exact-product suite → browser journey harness → DE/EN visual review → release ZIP.

The static pre-deployment build is binding-ready. Live current retailer prices are not claimed until production catalogue/offer sources are connected and qualified.
