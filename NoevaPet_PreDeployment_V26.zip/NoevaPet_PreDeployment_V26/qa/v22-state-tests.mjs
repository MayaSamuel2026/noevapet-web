import fs from 'fs';import vm from 'vm';import path from 'path';import {fileURLToPath} from 'url';
const __dirname=path.dirname(fileURLToPath(import.meta.url));const appPath=path.resolve(__dirname,'../assets/app.js');
const local=new Map(),session=new Map();const noop=()=>{};const classList={add:noop,remove:noop,toggle:noop,contains:()=>false};
function storage(map){return {getItem:k=>map.has(k)?map.get(k):null,setItem:(k,v)=>map.set(k,String(v)),removeItem:k=>map.delete(k),clear:()=>map.clear()}}
const document={documentElement:{lang:'en'},addEventListener:noop,querySelectorAll:()=>[],querySelector:()=>null,getElementById:()=>null,body:{classList,appendChild:noop},createElement:()=>({classList,style:{},dataset:{},appendChild:noop,addEventListener:noop,setAttribute:noop,insertAdjacentElement:noop,querySelectorAll:()=>[],querySelector:()=>null})};
const context={console,document,localStorage:storage(local),sessionStorage:storage(session),location:{pathname:'/en/tool.html',href:''},setTimeout:(f)=>{if(typeof f==='function')f();return 1},clearTimeout:noop,FormData:function(){},FileReader:function(){},Date,JSON,Math,Number,String,Array,Set,Map,Object,RegExp,URLSearchParams};context.window={document,localStorage:context.localStorage,sessionStorage:context.sessionStorage,location:context.location,addEventListener:noop,open:()=>null,print:noop};vm.createContext(context);vm.runInContext(fs.readFileSync(appPath,'utf8'),context,{filename:'app.js'});
const tests=[];function ok(name,cond,detail=''){tests.push({name,pass:!!cond,detail});if(!cond)throw new Error(`${name}: ${detail}`)}function j(k){try{return JSON.parse(local.get(k)||'null')}catch{return null}}
function seed(){local.clear();session.clear();local.set('npPets',JSON.stringify([{id:'maya',name:'Maya',type:'Dog',typeDe:'Hund',age:'13',ageDe:'13',photo:''}]));local.set('npActivePetId','maya');local.set('npRoutine:maya',JSON.stringify([{id:'vet',type:'food',name:'Vet Concept',nameDe:'Vet Concept',locked:true,buyNow:false,price:34.9}]));local.set('npNeeds:maya','[]');local.set('npPlan:maya','[]');local.set('npV18SeedMigration','1');local.set('npRoutineMigratedV6','1');local.set('npPlanMigratedV6','1');}
function choose(key){vm.runInContext(`npV6CurrentNeed='${key}'; addSuggestedNeedV6();`,context)}

// Orphan state cannot become a cart when there is no pet.
local.set('npPets','[]');local.delete('npActivePetId');local.set('npPlan:maya',JSON.stringify([{id:'ghost',name:'Ghost',price:9}]));ok('No-pet state cannot expose orphan basket data',context.getCartItemsV6().length===0,`cart=${context.getCartItemsV6().length}`);
seed();
// A later choice for the same need replaces rather than duplicates the earlier one.
for(const key of ['dry'])choose(key);const fakeBtn={dataset:{id:'cmp-dry-value',name:'Value dry food',nameDe:'Preisbewusstes Trockenfutter',subtitle:'comparison',subtitleDe:'Vergleich',img:'../assets/v18-packshot-dry.svg',zone:'zone-now',type:'food',price:'25.00',sourceNeed:'n-dry'},classList:{add(){}}};context.addPlanItem(fakeBtn);ok('Alternative selection replaces the previous product for the same need',j('npPlan:maya').length===1 && j('npPlan:maya')[0].id==='cmp-dry-value',JSON.stringify(j('npPlan:maya')));
// Checkout progress belongs to an exact cart signature.
local.set('npPlan:maya','[]');for(const key of ['dry','walk'])choose(key);vm.runInContext(`__npV6PurchaseMode='balance'`,context);let sigTargets=context.retailerTargetsV6();context.saveOpenedRetailersV8([sigTargets[0]]);ok('Checkout progress records opened retailer for current cart',context.openedRetailersV8().length===1,JSON.stringify(context.openedRetailersV8()));choose('treats');ok('Changing the cart invalidates stale checkout progress',context.openedRetailersV8().length===0,JSON.stringify(context.openedRetailersV8()));
// Explicit pet deletion cleanup removes pet-specific shopping state/history.
local.set('npPurchaseHistory:maya','[{"id":"x"}]');local.set('npLastPurchase:maya','{"id":"x"}');session.set('npCheckoutOpened:maya','["A"]');context.cleanupPetStateV20('maya');ok('Deleting a pet removes routine/needs/plan/history/checkout state',!local.has('npRoutine:maya')&&!local.has('npNeeds:maya')&&!local.has('npPlan:maya')&&!local.has('npPurchaseHistory:maya')&&!local.has('npLastPurchase:maya')&&!session.has('npCheckoutOpened:maya'),'all pet state removed');
seed();

seed();ok('Routine-only state has zero cart items',context.getCartItemsV6().length===0,`cart=${context.getCartItemsV6().length}`);
for(const key of ['dry','walk','treats'])choose(key);
ok('Three needs create exactly three concrete recommendations',j('npPlan:maya').length===3,JSON.stringify(j('npPlan:maya')));
ok('Resolved needs are not retained as open needs',j('npNeeds:maya').length===0,JSON.stringify(j('npNeeds:maya')));
ok('Cart count equals concrete recommendations',context.getCartItemsV6().length===3,`cart=${context.getCartItemsV6().length}`);

// Render-level regression test for the exact V21 problem: three resolved needs + one routine must render as four semantic nodes, not six.
const orbit={children:[],style:{setProperty(){}},appendChild(n){n.parentNode=this;this.children.push(n)},insertAdjacentElement(){},querySelector(){return null},querySelectorAll(sel){if(sel==='.match6-node')return this.children.filter(x=>String(x.className||'').includes('match6-node'));return []}};
document.getElementById=(id)=>id==='match6Orbit'?orbit:null;document.querySelector=()=>null;document.querySelectorAll=()=>[];document.createElement=()=>({className:'',style:{},dataset:{},innerHTML:'',parentNode:null,remove(){if(this.parentNode)this.parentNode.children=this.parentNode.children.filter(x=>x!==this)},appendChild(){},addEventListener(){},setAttribute(){}});
context.renderMatchOrbitV6();
ok('Rendered orbit has one routine + three selected products, not six mixed objects',orbit.children.length===4,`orbit=${orbit.children.length}`);
const rendered=orbit.children.map(x=>x.innerHTML).join(' | ');ok('Rendered orbit contains concrete products and excludes resolved need labels',rendered.includes('Vet Concept')&&rendered.includes('Balanced dry food')&&rendered.includes('Everyday harness set')&&rendered.includes('Small training treats')&&!rendered.includes('Open need'),rendered);
// Restore null DOM for the remaining state-only tests.
document.getElementById=()=>null;document.querySelector=()=>null;document.querySelectorAll=()=>[];

ok('Routine item not marked buyNow stays out of cart',!context.getCartItemsV6().some(x=>x.id==='vet'),'Vet Concept absent');
vm.runInContext(`saveRoutineV6(getRoutineV6().map(x=>x.id==='vet'?{...x,buyNow:true}:x));`,context);ok('Routine item explicitly selected for today enters cart',context.getCartItemsV6().length===4,`cart=${context.getCartItemsV6().length}`);
vm.runInContext(`saveRoutineV6(getRoutineV6().map(x=>x.id==='vet'?{...x,buyNow:false}:x));`,context);
// Duplicate same need choices must reconcile to one.
local.set('npPlan:maya',JSON.stringify([{id:'old',name:'Old',sourceNeed:'n-walk',type:'other',price:10},{id:'new',name:'New',sourceNeed:'n-walk',type:'other',price:12},{id:'rec-dry',name:'Dry',sourceNeed:'n-dry',type:'food',price:20}]));context.reconcilePetStateV22();const ded=j('npPlan:maya');ok('Reconciliation enforces one selected product per need',ded.length===2 && ded.some(x=>x.id==='new') && !ded.some(x=>x.id==='old'),JSON.stringify(ded));
// Restore four-item shopping trip and route tests.
local.set('npPlan:maya','[]');for(const key of ['dry','walk','treats','training'])choose(key);const four=context.getCartItemsV6();ok('Four selected recommendations produce four cart items',four.length===4,`cart=${four.length}`);
let groups=context.purchaseRouteGroupsV19(four,'balance');ok('Balance route allocates every product exactly once',groups.flatMap(g=>g.items).length===4 && new Set(groups.flatMap(g=>g.items).map(x=>x.cartId)).size===4,JSON.stringify(groups.map(g=>g.items.length)));
ok('Four-item balance route uses two retailers',groups.length===2,`retailers=${groups.length}`);
groups=context.purchaseRouteGroupsV19([four[0]],'balance');ok('One-item basket does not invent a second retailer',groups.length===1,`retailers=${groups.length}`);
groups=context.purchaseRouteGroupsV19(four,'simple');ok('Simple mode keeps four items with one retailer',groups.length===1 && groups[0].items.length===4,`retailers=${groups.length}`);
// Remove one choice and ensure exact decrement.
const removeId=j('npPlan:maya')[0].id;context.removePlanChoiceV20(removeId);ok('Removing one selected product decrements cart exactly once',context.getCartItemsV6().length===3,`cart=${context.getCartItemsV6().length}`);
// Pet separation.
local.set('npPets',JSON.stringify([{id:'maya',name:'Maya'},{id:'luna',name:'Luna'}]));local.set('npActivePetId','luna');local.set('npRoutine:luna','[]');local.set('npNeeds:luna','[]');local.set('npPlan:luna','[]');ok('Switching pets does not leak Maya cart into Luna',context.getCartItemsV6().length===0,`luna cart=${context.getCartItemsV6().length}`);
local.set('npActivePetId','maya');
// Checkout completion gate and purchase history.
local.set('npPlan:maya','[]');for(const key of ['dry','walk','treats'])choose(key);vm.runInContext(`__npV6PurchaseMode='balance'`,context);const targets=context.retailerTargetsV6();context.saveOpenedRetailersV8(targets);context.completeCheckoutV7();
const hist=j('npPurchaseHistory:maya')||[];ok('Completed checkout creates purchase history',hist.length===1,`history=${hist.length}`);ok('Purchase history preserves exact product count',hist[0]?.items?.length===3,`items=${hist[0]?.items?.length}`);ok('Completion clears active plan',j('npPlan:maya').length===0,JSON.stringify(j('npPlan:maya')));ok('Completion leaves saved routine but resets buyNow',j('npRoutine:maya').every(x=>x.buyNow===false),JSON.stringify(j('npRoutine:maya')));
const pass=tests.filter(x=>x.pass).length;console.log(JSON.stringify({status:pass===tests.length?'PASS':'FAIL',pass,total:tests.length,tests},null,2));
