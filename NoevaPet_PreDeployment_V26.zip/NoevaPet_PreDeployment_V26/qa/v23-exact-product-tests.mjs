import fs from 'fs';import vm from 'vm';import path from 'path';import {fileURLToPath} from 'url';
const __dirname=path.dirname(fileURLToPath(import.meta.url));const appPath=path.resolve(__dirname,'../assets/app.js');
const local=new Map(),session=new Map();const noop=()=>{};const classList={add:noop,remove:noop,toggle:noop,contains:()=>false};
function storage(map){return {getItem:k=>map.has(k)?map.get(k):null,setItem:(k,v)=>map.set(k,String(v)),removeItem:k=>map.delete(k),clear:()=>map.clear()}}
const document={documentElement:{lang:'en'},addEventListener:noop,querySelectorAll:()=>[],querySelector:()=>null,getElementById:()=>null,body:{classList,appendChild:noop},createElement:()=>({classList,style:{},dataset:{},appendChild:noop,addEventListener:noop,setAttribute:noop,insertAdjacentElement:noop,querySelectorAll:()=>[],querySelector:()=>null})};
const context={console,document,localStorage:storage(local),sessionStorage:storage(session),location:{pathname:'/en/tool.html',href:''},setTimeout:(f)=>{if(typeof f==='function')f();return 1},clearTimeout:noop,FormData:function(){},FileReader:function(){},Date,JSON,Math,Number,String,Array,Set,Map,Object,RegExp,URLSearchParams};context.window={document,localStorage:context.localStorage,sessionStorage:context.sessionStorage,location:context.location,addEventListener:noop,open:()=>null,print:noop};vm.createContext(context);vm.runInContext(fs.readFileSync(appPath,'utf8'),context,{filename:'app.js'});
const tests=[];function ok(name,cond,detail=''){tests.push({name,pass:!!cond,detail});if(!cond)throw new Error(`${name}: ${detail}`)}function j(k){try{return JSON.parse(local.get(k)||'null')}catch{return null}}
function base(){local.clear();session.clear();local.set('npPets',JSON.stringify([{id:'maya',name:'Maya',type:'Dog',typeDe:'Hund',age:'13',ageDe:'13'}]));local.set('npActivePetId','maya');local.set('npNeeds:maya','[]');local.set('npPlan:maya','[]');local.set('npV18SeedMigration','1');local.set('npRoutineMigratedV6','1');local.set('npPlanMigratedV6','1');}
function exact(intent='buy'){return {id:'vet',type:'food',name:'Vet Concept Low Fat Intestinal',nameDe:'Vet Concept Low Fat Intestinal',packSize:'3 kg',locked:intent!=='replace',buyNow:intent==='buy',exactProduct:true,offerSearch:intent==='buy',purchaseIntent:intent,price:34.90,img:'../assets/v18-packshot-dry.svg'}}
base();local.set('npRoutine:maya',JSON.stringify([exact('remember')]));
ok('Remember-only exact product stays out of today cart',context.getCartItemsV6().length===0,`cart=${context.getCartItemsV6().length}`);
ok('Remember-only exact product does not request retailer offer search',context.exactProductSearchRequestV23(exact('remember'))===null,'request=null');
base();local.set('npRoutine:maya',JSON.stringify([exact('buy')]));
let cart=context.getCartItemsV6();ok('Buy-again exact product enters cart exactly once',cart.length===1&&cart[0].id==='vet',JSON.stringify(cart));
const req=context.exactProductSearchRequestV23(cart[0]);ok('Buy-again exact product creates exact retailer-search request',req?.exact_match===true&&req?.pack_size==='3 kg'&&req?.strategy==='lowest_total_route',JSON.stringify(req));
ok('Exact product search preserves exact product name',req?.name==='Vet Concept Low Fat Intestinal',JSON.stringify(req));
let groups=context.purchaseRouteGroupsV19(cart,'balance');ok('Single exact product uses one retailer route',groups.length===1&&groups[0].items.length===1,JSON.stringify(groups.map(g=>g.items.length)));
ok('Route preserves exact product and pack size without substitution',groups[0].items[0].name==='Vet Concept Low Fat Intestinal'&&groups[0].items[0].packSize==='3 kg'&&groups[0].items[0].exactProduct===true,JSON.stringify(groups[0].items[0]));
// Mixed basket: exact repeat purchase + recommendation.
local.set('npPlan:maya',JSON.stringify([{id:'rec-walk',type:'other',name:'Everyday harness set',nameDe:'Alltagsgeschirr-Set',price:24.9,sourceNeed:'n-walk',img:'../assets/v18-packshot-walk.svg'}]));cart=context.getCartItemsV6();
ok('Exact repurchase and recommendation coexist without duplication',cart.length===2&&new Set(cart.map(x=>x.cartId)).size===2,JSON.stringify(cart.map(x=>x.cartId)));
groups=context.purchaseRouteGroupsV19(cart,'balance');ok('Mixed route allocates every product exactly once',groups.flatMap(g=>g.items).length===2&&new Set(groups.flatMap(g=>g.items).map(x=>x.cartId)).size===2,JSON.stringify(groups.map(g=>g.items.length)));
const routedExact=groups.flatMap(g=>g.items).find(x=>x.id==='vet');ok('Mixed route still preserves exact product identity',routedExact?.name==='Vet Concept Low Fat Intestinal'&&routedExact?.packSize==='3 kg'&&routedExact?.exactProduct===true,JSON.stringify(routedExact));
// Alternative intent: old exact product is context only; only the replacement enters cart.
base();local.set('npRoutine:maya',JSON.stringify([exact('replace')]));local.set('npPlan:maya',JSON.stringify([{id:'rec-dry',type:'food',name:'Balanced dry food',nameDe:'Ausgewogenes Trockenfutter',price:31.9,sourceNeed:'n-dry',img:'../assets/v18-packshot-dry.svg'}]));cart=context.getCartItemsV6();
ok('Find-alternative intent does not buy the old exact product',cart.length===1&&cart[0].id==='rec-dry'&&!cart.some(x=>x.id==='vet'),JSON.stringify(cart));
// Completion: immutable purchase history preserves exact-match fields, then routine resets to remember-only.
base();local.set('npRoutine:maya',JSON.stringify([exact('buy')]));vm.runInContext(`__npV6PurchaseMode='balance'`,context);const targets=context.retailerTargetsV6();context.saveOpenedRetailersV8(targets);context.completeCheckoutV7();
const hist=j('npPurchaseHistory:maya')||[];ok('Completed exact repurchase creates purchase record',hist.length===1,`history=${hist.length}`);
const bought=hist[0]?.items?.find(x=>x.id==='vet');ok('Purchase history preserves exact product metadata',bought?.exactProduct===true&&bought?.packSize==='3 kg'&&bought?.name==='Vet Concept Low Fat Intestinal',JSON.stringify(bought));
const routine=j('npRoutine:maya')||[];ok('After checkout exact product remains saved but no longer in today cart',routine[0]?.buyNow===false&&routine[0]?.purchaseIntent==='remember'&&routine[0]?.offerSearch===false,JSON.stringify(routine[0]));
const pass=tests.filter(x=>x.pass).length;console.log(JSON.stringify({status:pass===tests.length?'PASS':'FAIL',pass,total:tests.length,tests},null,2));
