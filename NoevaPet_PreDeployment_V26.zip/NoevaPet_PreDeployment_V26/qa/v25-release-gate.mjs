import {spawnSync} from 'child_process';import path from 'path';import fs from 'fs';import {fileURLToPath} from 'url';
const __dirname=path.dirname(fileURLToPath(import.meta.url));
const suites=['v22-state-tests.mjs','v23-exact-product-tests.mjs','v24-repurchase-tests.mjs','v25-interaction-tests.mjs','v25-state-matrix-tests.mjs','v25-static-check.mjs'];
const results=[];let total=0,pass=0,failed=false;
for(const suite of suites){const r=spawnSync(process.execPath,[path.join(__dirname,suite)],{encoding:'utf8'});let parsed=null;try{parsed=JSON.parse(r.stdout.trim())}catch(e){}const item={suite,status:r.status===0&&parsed?.status==='PASS'?'PASS':'FAIL',pass:parsed?.pass??0,total:parsed?.total??0,stderr:r.stderr.trim()};results.push(item);total+=item.total;pass+=item.pass;if(item.status!=='PASS')failed=true;}
const report={status:failed?'FAIL':'PASS',pass,total,suites:results,generated_at:new Date().toISOString(),browser_e2e:'Configured separately with Playwright/GitHub Actions; not executed by deterministic gate.'};
fs.writeFileSync(path.resolve(__dirname,'../QA_GATE_V25.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));if(failed)process.exit(1);
