const { test, expect } = require('@playwright/test');

async function seed(page,{pack='3 kg',needKey='dry',plan=true}={}){
  await page.goto('/de/index.html');
  await page.evaluate(({pack,needKey,plan})=>{
    localStorage.clear();sessionStorage.clear();
    localStorage.setItem('npPets',JSON.stringify([{id:'maya',name:'Maya',type:'Hund',typeDe:'Hund',age:'13',ageDe:'13'}]));
    localStorage.setItem('npActivePetId','maya');
    localStorage.setItem('npRoutine:maya',JSON.stringify([{id:'vet',type:'food',name:'Vet Concept',nameDe:'Vet Concept',packSize:pack,needKey,locked:true,buyNow:false,purchaseIntent:'remember',exactProduct:!!pack,offerSearch:false,img:'../assets/v18-packshot-dry.svg'}]));
    localStorage.setItem('npPlan:maya',JSON.stringify(plan?[{id:'rec-dry',type:'food',name:'Balanced dry food',nameDe:'Ausgewogenes Trockenfutter',price:31.9,sourceNeed:'n-dry',img:'../assets/v18-packshot-dry.svg'},{id:'rec-walk',type:'other',name:'Everyday harness set',nameDe:'Alltagsgeschirr-Set',price:24.9,sourceNeed:'n-walk',img:'../assets/v18-packshot-walk.svg'},{id:'rec-treats',type:'treats',name:'Small training treats',nameDe:'Kleine Trainingssnacks',price:11.8,sourceNeed:'n-treats',img:'../assets/v18-packshot-treats.svg'}]:[]));
    localStorage.setItem('npNeeds:maya','[]');
    localStorage.setItem('npV18SeedMigration','1');localStorage.setItem('npRoutineMigratedV6','1');localStorage.setItem('npPlanMigratedV6','1');
    localStorage.setItem('npQaMode','1');
  },{pack,needKey,plan});
}

test('exact repurchase click reconciles Pet Match and basket', async ({page})=>{
  await seed(page);
  await page.goto('/de/tool.html?qa=1');
  await expect(page.getByRole('button',{name:'Heute nachkaufen'})).toBeVisible();
  await page.getByRole('button',{name:'Heute nachkaufen'}).click();
  await expect(page.getByText('Vet Concept').first()).toBeVisible();
  await expect(page.getByText('Gewohnt · im Warenkorb').first()).toBeVisible();
  await expect(page.getByText('Ausgewogenes Trockenfutter')).toHaveCount(0);
  await expect(page.locator('[data-nav-cart-count]')).toHaveText('3');
  await expect(page.locator('#match21Summary .match21-summary-item')).toHaveCount(3);
  await expect(page.locator('#npQaPanelV25')).toContainText('QA PASS');
  await page.goto('/de/basket.html?qa=1');
  await expect(page.locator('#cart6List .cart6-line')).toHaveCount(3);
  await expect(page.getByText('Vet Concept').first()).toBeVisible();
  await expect(page.getByText('Ausgewogenes Trockenfutter')).toHaveCount(0);
  await expect(page.locator('#npQaPanelV25')).toContainText('QA PASS');
});

test('missing variant opens editor and only enters cart after confirmation',async({page})=>{
  await seed(page,{pack:''});
  await page.goto('/de/tool.html?qa=1');
  await page.getByRole('button',{name:/Heute nachkaufen/}).click();
  await expect(page.locator('#v6NeedModal')).toHaveClass(/show/);
  await expect(page.locator('#v6NeedName')).toHaveValue('Vet Concept');
  await page.locator('#v23PackSize').fill('3 kg');
  await page.locator('#v6SaveCurrent').click();
  await expect(page.locator('[data-nav-cart-count]')).toHaveText('3');
  await expect(page.locator('#match21Summary .match21-summary-item')).toHaveCount(3);
  await expect(page.getByText('Vet Concept · 3 kg').first()).toBeVisible();
  await expect(page.locator('#npQaPanelV25')).toContainText('QA PASS');
});

test('routine count and basket count remain deliberately different but explained',async({page})=>{
  await seed(page);
  await page.goto('/de/tool.html?qa=1');
  await expect(page.locator('#match22Legend')).toContainText('1 Alltagsprodukt');
  await expect(page.locator('#match22Legend')).toContainText('3 im Warenkorb');
  await expect(page.locator('#match21Summary .match21-summary-item')).toHaveCount(3);
  await page.goto('/de/basket.html?qa=1');
  await expect(page.locator('#cart6List .cart6-line')).toHaveCount(3);
});

for (const [lang,buyLabel] of [['de','Heute nachkaufen'],['en','Buy again today']]) {
  test(`${lang}: exact-ready repurchase action is wired`,async({page})=>{
    await seed(page);await page.goto(`/${lang}/tool.html?qa=1`);
    await expect(page.getByRole('button',{name:buyLabel})).toBeVisible();
    await page.getByRole('button',{name:buyLabel}).click();
    await expect(page.locator('[data-nav-cart-count]')).toHaveText('3');
    await expect(page.locator('#npQaPanelV25')).toContainText('QA PASS');
  });
}
