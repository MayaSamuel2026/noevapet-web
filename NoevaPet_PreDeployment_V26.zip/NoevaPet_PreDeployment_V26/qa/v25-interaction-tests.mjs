import fs from 'fs';import vm from 'vm';import path from 'path';import {fileURLToPath} from 'url';
const __dirname=path.dirname(fileURLToPath(import.meta.url));const appPath=path.resolve(__dirname,'../assets/app.js');
const local=new Map(),session=new Map(),elements=new Map();const noop=()=>{};
function storage(map){return {getItem:k=>map.has(k)?map.get(k):null,setItem:(k,v)=>map.set(k,String(v)),removeItem:k=>map.delete(k),clear:()=>map.clear()}}
class CL{constructor(){this.s=new Set()}add(...x){x.forEach(v=>this.s.add(v))}remove(...x){x.forEach(v=>this.s.delete(v))}toggle(x,on){if(on===undefined)on=!this.s.has(x);on?this.s.add(x):this.s.delete(x);return on}contains(x){return this.s.has(x)}}
function attrsToDataset(s){const d={};for(const m of s.matchAll(/data-([\w-]+)="([^"]*)"/g)){d[m[1].replace(/-([a-z])/g,(_,c)=>c.toUpperCase())]=m[2]}return d}
class El{
  constructor(id=''){this.id=id;this.classList=new CL();this.style={};this.dataset={};this.children=[];this.listeners={};this._html='';this.value='';this.checked=false;this.hidden=false;this.textContent='';this.focused=false;}
  set innerHTML(v){this._html=String(v);this.children=[];for(const m of this._html.matchAll(/<button([^>]*)>(.*?)<\/button>/gs)){const b=new El();b.dataset=attrsToDataset(m[1]);b.textContent=m[2].replace(/<[^>]+>/g,'').trim();this.children.push(b)}}
  get innerHTML(){return this._html}
  appendChild(x){this.children.push(x);return x}
  insertAdjacentElement(_,x){this.children.push(x);return x}
  addEventListener(t,f){(this.listeners[t]??=[]).push(f)}
  click(){for(const f of this.listeners.click||[])f({target:this,currentTarget:this,preventDefault:noop,stopPropagation:noop})}
  focus(){this.focused=true}
  setAttribute(){}
  removeAttribute(){}
  querySelectorAll(sel){let out=[];for(const c of this.children){if(match(c,sel))out.push(c);out=out.concat(c.querySelectorAll(sel))}return out}
  querySelector(sel){return this.querySelectorAll(sel)[0]||null}
  closest(){return null}
}
function match(el,sel){
  if(sel.startsWith('[data-')){const raw=sel.match(/^\[data-([^\]]+)\]$/)?.[1];if(!raw)return false;const k=raw.replace(/-([a-z])/g,(_,c)=>c.toUpperCase());return Object.prototype.hasOwnProperty.call(el.dataset,k)}
  if(sel.startsWith('.'))return el.classList.contains(sel.slice(1));return false;
}
function field(v=''){const e=new El();e.value=v;return e}
let selectedIntent='buy';
const document={
  documentElement:{lang:'de'},body:new El('body'),
  addEventListener:noop,createElement:()=>new El(),getElementById:id=>elements.get(id)||null,
  querySelectorAll:sel=>[],
  querySelector:sel=>{
    if(sel==='input[name="v23PurchaseIntent"]:checked')return {value:selectedIntent};
    const m=sel.match(/^input\[name="v23PurchaseIntent"\]\[value="([^"]+)"\]$/);if(m)return {value:m[1],checked:m[1]===selectedIntent};
    return null;
  }
};
const context={console,document,localStorage:storage(local),sessionStorage:storage(session),location:{pathname:'/de/tool.html',search:'',href:'',reload:noop},setTimeout:(f)=>{if(typeof f==='function')f();return 1},clearTimeout:noop,FormData:function(){},FileReader:function(){},Date,JSON,Math,Number,String,Array,Set,Map,Object,RegExp,URLSearchParams,MutationObserver:undefined};context.window={document,localStorage:context.localStorage,sessionStorage:context.sessionStorage,location:context.location,addEventListener:noop,open:()=>null,print:noop};vm.createContext(context);vm.runInContext(fs.readFileSync(appPath,'utf8'),context,{filename:'app.js'});
const tests=[];function ok(name,cond,detail=''){tests.push({name,pass:!!cond,detail});if(!cond)throw new Error(`${name}: ${detail}`)}function j(k){try{return JSON.parse(local.get(k)||'null')}catch{return null}}
function base(){local.clear();session.clear();elements.clear();local.set('npPets',JSON.stringify([{id:'maya',name:'Maya',type:'Dog',typeDe:'Hund',age:'13',ageDe:'13'}]));local.set('npActivePetId','maya');local.set('npNeeds:maya','[]');local.set('npV18SeedMigration','1');local.set('npRoutineMigratedV6','1');local.set('npPlanMigratedV6','1');elements.set('match6Current',new El('match6Current'));}
function installEditor(){const ids=['v6NeedModal','v6NeedTitle','v6NeedType','v6NeedName','v6KeepExact','v6BuyNow','v6CurrentPanel','v6SuggestPanel','v23PackSize','v23ExactError','v6SaveCurrent'];for(const id of ids)elements.set(id,field());elements.get('v6NeedModal').classList=new CL();elements.get('v6CurrentPanel').style={};elements.get('v6SuggestPanel').style={};elements.get('v6KeepExact').checked=true;elements.get('v6BuyNow').checked=true;}
const plan=[{id:'rec-dry',type:'food',name:'Balanced dry food',nameDe:'Ausgewogenes Trockenfutter',price:31.9,sourceNeed:'n-dry',img:'../assets/v18-packshot-dry.svg'},{id:'rec-walk',type:'other',name:'Everyday harness set',nameDe:'Alltagsgeschirr-Set',price:24.9,sourceNeed:'n-walk',img:'../assets/v18-packshot-walk.svg'},{id:'rec-treats',type:'treats',name:'Small training treats',nameDe:'Kleine Trainingssnacks',price:11.8,sourceNeed:'n-treats',img:'../assets/v18-packshot-treats.svg'}];

// Exact-ready repurchase must be wired to the visible button and reconcile cart + recommendation.
base();local.set('npRoutine:maya',JSON.stringify([{id:'vet',type:'food',name:'Vet Concept Low Fat Intestinal',nameDe:'Vet Concept Low Fat Intestinal',packSize:'3 kg',needKey:'dry',locked:true,buyNow:false,purchaseIntent:'remember',exactProduct:true,offerSearch:false}]));local.set('npPlan:maya',JSON.stringify(plan));context.renderMatchCurrentV6();
let host=elements.get('match6Current');let buy=host.querySelectorAll('[data-match-v24-buy]')[0];
ok('Rendered routine card exposes a clickable repurchase action',!!buy&&buy.dataset.matchV24Buy==='vet',host.innerHTML+host.children.map(x=>x.innerHTML).join(''));
ok('Repurchase action has a click listener attached',Array.isArray(buy.listeners.click)&&buy.listeners.click.length>0,`listeners=${buy.listeners.click?.length||0}`);
buy.click();let cart=context.getCartItemsV6(),routine=j('npRoutine:maya'),p=j('npPlan:maya');
ok('Clicking repurchase actually changes canonical routine state',routine[0]?.buyNow===true&&routine[0]?.offerSearch===true,JSON.stringify(routine[0]));
ok('Clicking repurchase removes same-need recommendation',!p.some(x=>x.sourceNeed==='n-dry'),JSON.stringify(p));
ok('Pet Match action and basket reconcile to one dry-food purchase',cart.length===3&&cart.some(x=>x.id==='vet')&&!cart.some(x=>x.id==='rec-dry'),JSON.stringify(cart.map(x=>x.id)));
ok('Runtime state invariant audit passes after repurchase click',context.npInvariantReportV25().pass,JSON.stringify(context.npInvariantReportV25()));

// Missing variant must open editor instead of becoming a dead button.
base();installEditor();local.set('npRoutine:maya',JSON.stringify([{id:'vet',type:'food',name:'Vet Concept',nameDe:'Vet Concept',needKey:'dry',locked:true,buyNow:false,purchaseIntent:'remember'}]));local.set('npPlan:maya',JSON.stringify(plan));context.renderMatchCurrentV6();host=elements.get('match6Current');buy=host.querySelectorAll('[data-match-v24-buy]')[0];
ok('Missing-variant routine still renders repurchase action',!!buy,buy?.textContent||'missing');buy.click();
ok('Missing-variant repurchase opens the product editor',elements.get('v6NeedModal').classList.contains('show'),'modal not shown');
ok('Repurchase editor is prefilled with saved product',elements.get('v6NeedName').value==='Vet Concept',elements.get('v6NeedName').value);
ok('Repurchase editor directs focus to missing pack size',elements.get('v23PackSize').focused===true,'pack not focused');
ok('Dead-action regression is prevented: state remains unchanged until exact variant confirmed',context.getCartItemsV6().length===3&&!j('npRoutine:maya')[0].buyNow,JSON.stringify({cart:context.getCartItemsV6().length,routine:j('npRoutine:maya')[0]}));

const pass=tests.filter(x=>x.pass).length;console.log(JSON.stringify({status:pass===tests.length?'PASS':'FAIL',pass,total:tests.length,tests},null,2));
