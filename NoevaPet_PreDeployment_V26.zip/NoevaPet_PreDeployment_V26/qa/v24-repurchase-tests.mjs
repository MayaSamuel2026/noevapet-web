import fs from 'fs';import vm from 'vm';import path from 'path';import {fileURLToPath} from 'url';
const __dirname=path.dirname(fileURLToPath(import.meta.url));const appPath=path.resolve(__dirname,'../assets/app.js');
const local=new Map(),session=new Map(),els=new Map();const noop=()=>{};const classList={add:noop,remove:noop,toggle:noop,contains:()=>false};
function storage(map){return {getItem:k=>map.has(k)?map.get(k):null,setItem:(k,v)=>map.set(k,String(v)),removeItem:k=>map.delete(k),clear:()=>map.clear()}}
let intent='buy';
const document={documentElement:{lang:'en'},addEventListener:noop,querySelectorAll:()=>[],querySelector:(s)=>s.includes('v23PurchaseIntent')?{value:intent}:null,getElementById:id=>els.get(id)||null,body:{classList,appendChild:noop},createElement:()=>({classList,style:{},dataset:{},appendChild:noop,addEventListener:noop,setAttribute:noop,insertAdjacentElement:noop,querySelectorAll:()=>[],querySelector:()=>null})};
const context={console,document,localStorage:storage(local),sessionStorage:storage(session),location:{pathname:'/en/tool.html',href:''},setTimeout:(f)=>{if(typeof f==='function')f();return 1},clearTimeout:noop,FormData:function(){},FileReader:function(){},Date,JSON,Math,Number,String,Array,Set,Map,Object,RegExp,URLSearchParams};context.window={document,localStorage:context.localStorage,sessionStorage:context.sessionStorage,location:context.location,addEventListener:noop,open:()=>null,print:noop};vm.createContext(context);vm.runInContext(fs.readFileSync(appPath,'utf8'),context,{filename:'app.js'});
const tests=[];function ok(name,cond,detail=''){tests.push({name,pass:!!cond,detail});if(!cond)throw new Error(`${name}: ${detail}`)}function j(k){try{return JSON.parse(local.get(k)||'null')}catch{return null}}
function field(value=''){return {value,checked:true,hidden:false,textContent:'',style:{},classList:{add:noop,remove:noop,toggle:noop},focus:noop}}
function setupFields(name='Vet concept',pack='3 kg'){els.clear();els.set('v6NeedName',field(name));els.set('v6NeedType',field('food'));els.set('v23PackSize',field(pack));els.set('v6KeepExact',field());els.set('v6BuyNow',field());els.set('v23ExactError',field());els.set('v6NeedModal',{classList:{remove:noop,add:noop}});}
function base(){local.clear();session.clear();local.set('npPets',JSON.stringify([{id:'maya',name:'Maya',type:'Dog',typeDe:'Hund',age:'13',ageDe:'13'}]));local.set('npActivePetId','maya');local.set('npNeeds:maya','[]');local.set('npV18SeedMigration','1');local.set('npRoutineMigratedV6','1');local.set('npPlanMigratedV6','1');}
const plan=[{id:'rec-dry',type:'food',name:'Balanced dry food',nameDe:'Ausgewogenes Trockenfutter',price:31.9,sourceNeed:'n-dry',img:'../assets/v18-packshot-dry.svg'},{id:'rec-walk',type:'other',name:'Everyday harness set',nameDe:'Alltagsgeschirr-Set',price:24.9,sourceNeed:'n-walk',img:'../assets/v18-packshot-walk.svg'},{id:'rec-treats',type:'treats',name:'Small training treats',nameDe:'Kleine Trainingssnacks',price:11.8,sourceNeed:'n-treats',img:'../assets/v18-packshot-treats.svg'}];

// Legacy saved product with no originating need: buying it today adds a fourth basket line.
base();setupFields();local.set('npRoutine:maya',JSON.stringify([{id:'vet',type:'food',name:'Vet concept',nameDe:'Vet concept',locked:true,buyNow:false,purchaseIntent:'remember'}]));local.set('npPlan:maya',JSON.stringify(plan));vm.runInContext("npV24EditingRoutineId='vet';npV24EditingNeedKey='';",context);context.addCurrentProductV6();
let routine=j('npRoutine:maya'),p=j('npPlan:maya'),cart=context.getCartItemsV6();let vet=routine.find(x=>x.id==='vet');
ok('Repurchase editor updates the existing routine item instead of duplicating it',routine.length===1&&vet?.id==='vet',JSON.stringify(routine));
ok('Repurchase captures exact pack size and exact-product semantics',vet?.packSize==='3 kg'&&vet?.exactProduct===true&&vet?.offerSearch===true&&vet?.buyNow===true,JSON.stringify(vet));
ok('Legacy routine item with unknown category becomes fourth basket item',cart.length===4,JSON.stringify(cart.map(x=>x.id)));
ok('Unrelated recommendations remain intact when originating need is unknown',p.length===3,JSON.stringify(p.map(x=>x.sourceNeed)));

// Known dry-food routine: exact repurchase supersedes the dry recommendation, preventing duplication.
base();setupFields();local.set('npRoutine:maya',JSON.stringify([{id:'vet',type:'food',name:'Vet concept',nameDe:'Vet concept',locked:true,buyNow:false,purchaseIntent:'remember',needKey:'dry'}]));local.set('npPlan:maya',JSON.stringify(plan));vm.runInContext("npV24EditingRoutineId='vet';npV24EditingNeedKey='dry';",context);context.addCurrentProductV6();
routine=j('npRoutine:maya');p=j('npPlan:maya');cart=context.getCartItemsV6();vet=routine.find(x=>x.id==='vet');
ok('Known need repurchase enters basket',vet?.buyNow===true&&cart.some(x=>x.id==='vet'),JSON.stringify(cart.map(x=>x.id)));
ok('Exact repurchase removes recommendation for the same dry-food need',!p.some(x=>x.sourceNeed==='n-dry'),JSON.stringify(p.map(x=>x.sourceNeed)));
ok('Other recommendations are preserved',p.some(x=>x.sourceNeed==='n-walk')&&p.some(x=>x.sourceNeed==='n-treats'),JSON.stringify(p.map(x=>x.sourceNeed)));
ok('Known-need basket count stays congruent at three, with no duplicate dry-food intent',cart.length===3&&new Set(cart.map(x=>x.cartId)).size===3,JSON.stringify(cart.map(x=>x.cartId)));

// Removing today's repurchase must return it to routine-only and drop basket count by one.
local.set('npRoutine:maya',JSON.stringify(routine.map(x=>x.id==='vet'?{...x,buyNow:false,purchaseIntent:'remember',offerSearch:false}:x)));cart=context.getCartItemsV6();
ok('Removing exact repurchase from today keeps routine item but removes it from basket',cart.length===2&&!cart.some(x=>x.id==='vet')&&(j('npRoutine:maya')||[]).some(x=>x.id==='vet'),JSON.stringify(cart.map(x=>x.id)));

// Exact search request remains canonical.
const req=context.exactProductSearchRequestV23({...vet,buyNow:true,offerSearch:true});
ok('Exact repurchase still produces retailer-search request',req?.exact_match===true&&req?.pack_size==='3 kg'&&req?.strategy==='lowest_total_route',JSON.stringify(req));

const pass=tests.filter(x=>x.pass).length;console.log(JSON.stringify({status:pass===tests.length?'PASS':'FAIL',pass,total:tests.length,tests},null,2));
