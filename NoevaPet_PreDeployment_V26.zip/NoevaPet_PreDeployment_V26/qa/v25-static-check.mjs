import fs from 'fs';import path from 'path';import vm from 'vm';import {fileURLToPath} from 'url';
const __dirname=path.dirname(fileURLToPath(import.meta.url));const root=path.resolve(__dirname,'..');
const tests=[];function ok(name,cond,detail=''){tests.push({name,pass:!!cond,detail});if(!cond)process.exitCode=1}
const langs=['de','en'];const pages={};
for(const lang of langs){pages[lang]=fs.readdirSync(path.join(root,lang)).filter(f=>f.endsWith('.html')).sort()}
ok('DE/EN page sets are identical',JSON.stringify(pages.de)===JSON.stringify(pages.en),JSON.stringify(pages));
for(const lang of langs){for(const file of pages[lang]){const full=path.join(root,lang,file),html=fs.readFileSync(full,'utf8');
  const ids=[...html.matchAll(/\bid="([^"]+)"/g)].map(m=>m[1]);const dup=[...new Set(ids.filter((x,i)=>ids.indexOf(x)!==i))];ok(`${lang}/${file}: no duplicate ids`,dup.length===0,dup.join(','));
  ok(`${lang}/${file}: loads runtime config`,html.includes('../assets/runtime-config.js'),'runtime-config.js missing');
  ok(`${lang}/${file}: loads app.js`,html.includes('../assets/app.js'),'app.js missing');
  const refs=[...html.matchAll(/\b(?:src|href)="([^"]+)"/g)].map(m=>m[1]).filter(r=>r&&!r.startsWith('#')&&!/^(?:https?:|mailto:|tel:|javascript:|data:)/i.test(r));
  for(const ref0 of refs){const ref=ref0.split('#')[0].split('?')[0];if(!ref)continue;const target=path.resolve(path.dirname(full),ref);ok(`${lang}/${file}: local reference ${ref}`,fs.existsSync(target),target)}
  ok(`${lang}/${file}: Pet Match is reachable`,html.includes('href="tool.html"')||file==='tool.html','tool.html link missing');
}}
for(const file of pages.en){const html=fs.readFileSync(path.join(root,'en',file),'utf8');ok(`en/${file}: no German pet-meta placeholder`,!html.includes('4 Jahre · großer Hund'),'German placeholder leaked into EN');}
for(const lang of langs){const tool=fs.readFileSync(path.join(root,lang,'tool.html'),'utf8');ok(`${lang}/tool: exact pack field exists`,tool.includes('id="v23PackSize"'),'v23PackSize missing');ok(`${lang}/tool: purchase-intent inputs exist`,tool.includes('name="v23PurchaseIntent"'),'purchase intent missing');ok(`${lang}/tool: routine host exists`,tool.includes('id="match6Current"'),'match6Current missing');ok(`${lang}/tool: orbit exists`,tool.includes('id="match6Orbit"'),'match6Orbit missing');}
const app=fs.readFileSync(path.join(root,'assets/app.js'),'utf8');try{new vm.Script(app);ok('assets/app.js syntax',true)}catch(e){ok('assets/app.js syntax',false,e.message)}
for(const token of ['npInvariantReportV25','npDomInvariantReportV25','NoevaPetQA','data-match-v24-buy','exactProductSearchRequestV23'])ok(`app contains ${token}`,app.includes(token),token+' missing');
const pass=tests.filter(x=>x.pass).length;console.log(JSON.stringify({status:pass===tests.length?'PASS':'FAIL',pass,total:tests.length,tests},null,2));if(pass!==tests.length)process.exit(1);
