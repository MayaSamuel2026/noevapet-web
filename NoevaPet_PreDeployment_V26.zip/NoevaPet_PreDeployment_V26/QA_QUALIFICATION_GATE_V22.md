# NoevaPet Qualification Gate v1 — V22

A version is not considered release-ready merely because it builds or because individual page components work. The same pet/shopping state must reconcile across every surface.

## Canonical entities

1. PET — active profile and context.
2. ROUTINE ITEM — a product the pet already uses. It may or may not be bought today.
3. OPEN NEED — a temporary unanswered requirement.
4. SELECTED PRODUCT — a concrete product chosen to solve a need; it is part of today's cart.
5. RETAILER ALLOCATION — where each selected cart product is handed off.
6. PURCHASE RECORD — immutable snapshot created after user-confirmed retailer checkout.

## Hard invariants

- A resolved need must not remain visible as an equal product-like object.
- There can be at most one selected product per originating need.
- Routine item with `buyNow=false` is visible in the pet context but excluded from cart counts.
- Routine item with `buyNow=true` appears exactly once in cart counts.
- Selected recommendation appears exactly once in Pet Match purchase state, cart, buying route, review, retailer allocation, receipt and history.
- Basket product count must equal buying-route allocation count, review product count and checkout product count.
- Changing the basket or purchase mode invalidates stale retailer-open progress.
- Switching pet changes all pet-specific routine/needs/plan/history state.
- No active pet means no accessible orphan cart/plan state.
- Completion writes purchase history before clearing the active shopping trip.
- Completion clears selected recommendations/open needs but preserves saved routine products with `buyNow=false`.
- A one-product cart does not invent a second retailer.
- Simple mode keeps the route to one retailer.
- Removing one selected product decrements all purchase-related counts exactly once.
- Deleting a pet removes that pet's routine, needs, plan, checkout session and purchase history.

## Journey matrix

The browser-level qualification harness covers DE and EN and tests:

1. active pet propagation;
2. saved routine without purchase;
3. dry-food recommendation;
4. walk recommendation;
5. treat recommendation;
6. resolved-needs disappearance;
7. orbit semantic states;
8. cart-count reconciliation;
9. homepage basket reconciliation;
10. four-item homepage preview;
11. basket line count;
12. buying-route allocation count;
13. review-stage count;
14. retailer-handoff count;
15. completion gate;
16. receipt count;
17. history count/product detail;
18. direct Pet Match access without a pet.

## Release sequence

BUILD → static integrity → state-model tests → browser journey tests → visual evidence review → DE/EN parity → desktop/mobile review → release ZIP.

Any blocking failure returns the build to correction. A PASS is only a release qualification; it does not replace production catalogue/retailer/legal binding validation.
